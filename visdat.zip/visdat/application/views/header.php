<nav class="navbar navbar-inverse navbar-fixed-top" style="width : 100%">
        <div class="container">
                <!-- <a href="index.php"><img src="<?=base_url()?>assets/images/logo.jpg"class="navbar-brand" ></a> -->
                <ul style="text-align:center; color:white;"  class="nav navbar-nav  center-block ">
                <li style="margin-left:250px; " ><h4>Visualisasi Data Potensi Desa Indikator Lingkungan Provinsi DI Yogyakarta</h4></li>
                </ul>
                <img src="<?=base_url()?>assets/images/stis.png" class="nav navbar-nav navbar-right" width=50px;>
                <ul class="nav navbar-nav navbar-right">
                <li><a>3 Sains Data 2</a></li>
                </ul>
                
        </div>
</nav>

